import { LightningElement, wire } from 'lwc';
import getCarTypes from '@salesforce/apex/CarSearchFormController.getCarTypes';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class CarSearchForm extends NavigationMixin(LightningElement) {

    carTypes;

    @wire(getCarTypes)
    wiredCarTypes({data, error}){
        if(data){
            this.carTypes = [{value : '', label : 'All Types'}];
            data.forEach(element => {
                const carType = {}; 
                carType.label = element.Name;
                carType.value = element.Id;

                this.carTypes.push(carType);
            });
        }else if(error){
            this.showToast('ERROR', error.body.message, 'error');
        }
    }

    handleCarTypeChange(event){
        const carTypeId = event.detail.value;
        //alert(carTypeId);
        const carTypeSelectionChangeEvent = new CustomEvent('carTypeSelect', {detail : carTypeId});
        this.dispatchEvent(carTypeSelectionChangeEvent);
    }

    createNewCarType(){

        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Car_Type__c',
                actionName: 'new',
            },
        });
    }

    showToast(title, message, varient) {
        const evt = new ShowToastEvent({
            title: title,
            message : message,
            varient : value,
        });
        this.dispatchEvent(evt);
    }
}