import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getAllAccount from '@salesforce/apex/ManageAccountRecords.getAccount';

export default class AccountManageData extends LightningElement {

    numberOfAccount;
     accounts;

    get responseReceived(){
        if(this.accounts){
            return true;
        }
        return false;
    }

    numberOfAccountChangeHandler(event){
        this.numberOfAccount = event.target.value;
    }

    getAccounts(){
        getAllAccount({numberOfAccount:this.numberOfAccount}).then(response =>{
            this.accounts = response;

            const evt = new ShowToastEvent({
                title: 'Account Creater',
                message: this.numberOfAccount + 'Accounts fetched from Server',
                variant: 'success',
            });
            this.dispatchEvent(evt);

        }).catch(error =>{
            console.error('Error in getting the accounts', error.body.message);

            const evt = new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error',
            });
            this.dispatchEvent(evt);
        })
    }
}