import { LightningElement, wire } from 'lwc';
import {registerListener, unregisterAllListeners} from 'c/pubsub';
import {CurrentPageReference} from 'lightning/navigation';
 
export default class SelectedMeetingRoom_PubSub extends LightningElement {


    selectedMeetingRoom = {};
    @wire(CurrentPageReference) pageRef;

    connectedCallback(){
        registerListener('pubsubTileClicke', this.onMeetingRomSelectHandler, this)
    }

    disconnectedCallback(){
        unregisterAllListeners(this);
    }
    
    onMeetingRomSelectHandler(payload){

        this.selectedMeetingRoom = payload;

    }
}