import { LightningElement } from 'lwc';

import ACC_NAME from '@salesforce/schema/Account.Name';
import ACC_PHONE from '@salesforce/schema/Account.Phone';
import ACC_WEBSITE from '@salesforce/schema/Account.Website';


export default class AccountRecordsForm extends LightningElement {

    recordId;

    filedsArray = [ ACC_NAME, ACC_PHONE, ACC_WEBSITE];

    handelSucess(event){

        this.recordId = event.detail.id;
    }
}