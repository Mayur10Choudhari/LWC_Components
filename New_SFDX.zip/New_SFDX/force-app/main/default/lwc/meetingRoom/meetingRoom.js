import { LightningElement, api, wire } from 'lwc';
import {fireEvent} from 'c/pubsub';
import {CurrentPageReference} from 'lightning/navigation';


export default class MeetingRoom extends LightningElement {

    @api meetingRoomInfo;

    @wire(CurrentPageReference) pageReference;

    @api showRoomInfo = false;

    tileClickHandler(){
        
        const tileClicked = new CustomEvent('tileClick', {detail : this.meetingRoomInfo, bubbles : true});

        this.dispatchEvent(tileClicked);
        fireEvent(this.pageReference, 'pubsubTileClicke', this.meetingRoomInfo);
    }
}