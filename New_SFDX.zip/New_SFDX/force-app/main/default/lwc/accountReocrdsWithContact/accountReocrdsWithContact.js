import { LightningElement, wire } from 'lwc';
import getAllAccount from '@salesforce/apex/ApexTypesController.getAccount';


import FIRSTNAME_FIELD from '@salesforce/schema/Account.Name';
import ACCOUNT_SOURCE from '@salesforce/schema/Account.AccountSource';
import ANNUAL_REVENUE from '@salesforce/schema/Account.AnnualRevenue';
import NUMBER_OF_LOCATIONS from '@salesforce/schema/Account.NumberofLocations__c';


const SFDCField = [
    {
        label: 'NAME',
        fieldName: FIRSTNAME_FIELD.fieldApiName,
        editable: true
    },
    {
        label: 'Account Source',
        fieldName: ACCOUNT_SOURCE.fieldApiName,
        editable: true
    },
    { 
        label: 'Annual Revenue', 
        fieldName: ANNUAL_REVENUE.fieldApiName, 
        editable: true 
    },
    {
        label: 'Number Of Locations',
        fieldName: NUMBER_OF_LOCATIONS.fieldApiName,
        type: 'phone',
        editable: true
    }
];

export default class AccountReocrdsWithContact extends LightningElement {

    
    columns = SFDCField; 

    @wire(getAllAccount)
    accounts;

    async handleSave(event){
        // Convert datatable draft values into record objects
        const records = event.detail.draftValues.slice().map((draftValue) => {
            const fields = Object.assign({}, draftValue);
            return { fields };
        });

        // Clear all datatable draft values
        this.draftValues = [];

        try {
            // Update all records in parallel using UI API
            const recordUpdatePromises = records.map((record) =>
                updateRecord(record)
            );
            await Promise.all(recordUpdatePromises);

            // Report success with a toast
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Contacts updated',
                    variant: 'success'
                })
            );

            // Display fresh data in the datatable
            await refreshApex(this.accounts);
        } catch (error) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error updating or reloading contacts',
                    message: error.body.message,
                    variant: 'error'
                })
            );
        }
    }
}