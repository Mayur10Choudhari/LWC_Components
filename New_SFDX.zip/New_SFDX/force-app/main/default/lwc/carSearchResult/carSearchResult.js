import { LightningElement, api, wire } from 'lwc';
import getCars from '@salesforce/apex/CarSearchResultController.getCars';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


export default class CarSearchResult extends LightningElement {

    @api carTypeId; //this carTypeId supply by parent componet that will be recived in our carSearchResult component
    cars; //we store a a data inside cars

    @wire(getCars, {carTypeId : '$carTypeId'})
    wiredCars({data, error}){
        alert('data is   ' + data);
        console.log(JSON.stringify(data));
        if( data){
            this.cars = data;
        }else if(error){
           this.showToast('ERROR', error.body.message, 'error'); 
        }
    }

    showToast() {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }

    get carFounds(){
        if(this.cars){
            return true;
        }
        else return false;
    }
}