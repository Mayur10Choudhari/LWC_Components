import { LightningElement, wire } from 'lwc';
import { createRecord, getRecord } from 'lightning/uiRecordApi';

const fieldArray = ['Account.Name', 'Account.Phone', 'Account.Website'];

export default class CreatingAccountRecordLDS extends LightningElement {

    accountName;
    accountPhone;
    accountUrl;

    recordId; // to hold a records id get a data from server

    @wire(getRecord, {recordId: '$recordId', fields : fieldArray})

    accountRecords;

    AccountNameHnadler(event){
        this.accountName = event.target.value;
    }

    AccountPhoneHnadler(event){
        this.accountPhone = event.target.value;
    }

    AccountUrlHandler(event){
        this.accountUrl = event.target.value;
    }

    onClickCreateRecord(){
        // Note - if you are using custom object then you have to pass custom object API Name 'FieldApiName' : this.name
        const fields = {'Name' : this.accountName, 'Phone' : this.accountPhone, 'Website' : this.accountUrl};
        
        //Note - then we have to create a javascript object(API Name) to map this fields to with their object
        const recordInput = {apiName : 'Account', fields};

        /* Note - now we have to make a call createRecord method from LDS
        which is going to take  recordInput as a parameter and going to 
        create a account record in backend */

        createRecord(recordInput).then(response => {
                                            console.log('Account has been created', response.id);
                                            this.recordId = response.id;
                                       }).catch(error => {
                                            console.log(error.body.message);
                                       })
    }

    get retriveAccountName(){
            if(this.accountRecords.data){
                return this.accountRecords.data.fields.Name.value;
            }
            return undefined;
    }

    get retriveAccountPhone(){
            if(this.accountRecords.data){
                return this.accountRecords.data.fields.Phone.value;
            }
            return undefined;
    }

    get retriveAccountUrl(){
            if(this.accountRecords.data){
                return this.accountRecords.data.fields.Website.value;
            }
            return undefined;
    }
}