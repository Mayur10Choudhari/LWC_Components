import { LightningElement } from 'lwc';

export default class MeetingParentRooms extends LightningElement {

    selectedMeetingInfo;
    meetingRoomInfo = [
        {roomName: 'A-01' ,roomCapacity: '12'},
        {roomName: 'A-02' ,roomCapacity: '11'},
        {roomName: 'A-03' ,roomCapacity: '10'},
        {roomName: 'B-01' ,roomCapacity: '15'},
        {roomName: 'B-02' ,roomCapacity: '18'},
        {roomName: 'B-03' ,roomCapacity: '20'}
    ];

    onTileClickSelectorHandler(event){

        const meetingRoomInfo = event.detail;
        this.selectedMeetingInfo = meetingRoomInfo.roomName;

    }

    constructor(){
        super();
        this.template.addEventListener('tileClick', this.onTileClickSelectorHandler.bind(this));
    }
}